import { Component } from '@angular/core';

@Component({
  selector: 'app-account-page',
  imports: [],
  templateUrl: './account-page.component.html',
  styleUrl: './account-page.component.css'
})
export class AccountPageComponent {

}
