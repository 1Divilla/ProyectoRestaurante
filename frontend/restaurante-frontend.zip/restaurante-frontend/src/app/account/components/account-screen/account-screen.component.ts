import { Component } from '@angular/core';

@Component({
  selector: 'app-account-screen',
  imports: [],
  templateUrl: './account-screen.component.html',
  styleUrl: './account-screen.component.css'
})
export class AccountScreenComponent {

}
