import { Component } from '@angular/core';

@Component({
  selector: 'app-table-selector',
  imports: [],
  standalone : true,
  templateUrl: './table-selector.component.html',
  styleUrl: './table-selector.component.css'
})
export class TableSelectorComponent {

}
