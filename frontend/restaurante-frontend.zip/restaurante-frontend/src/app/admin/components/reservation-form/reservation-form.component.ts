import { Component } from '@angular/core';

@Component({
  selector: 'app-reservation-form',
  imports: [],
  templateUrl: './reservation-form.component.html',
  styleUrl: './reservation-form.component.css'
})
export class ReservationFormComponent {

}
