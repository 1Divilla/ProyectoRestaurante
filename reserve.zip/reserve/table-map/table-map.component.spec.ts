import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableMapComponent } from './table-map.component';

describe('TableMapComponent', () => {
  let component: TableMapComponent;
  let fixture: ComponentFixture<TableMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TableMapComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TableMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
