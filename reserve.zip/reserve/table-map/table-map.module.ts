import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableMapRoutingModule } from './table-map-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TableMapRoutingModule
  ]
})
export class TableMapModule { }
