import { Component } from '@angular/core';

@Component({
  selector: 'app-table-map',
  templateUrl: './table-map.component.html',
  styleUrls: ['./table-map.component.css']
})
export class TableMapComponent {
  tables = [
    { id: 1, x: 50, y: 50, selected: false },
    { id: 2, x: 120, y: 50, selected: false },
    { id: 3, x: 50, y: 120, selected: false },
    { id: 4, x: 120, y: 120, selected: false }
  ];

  draggingTable: any = null;
  offsetX = 0;
  offsetY = 0;

  toggleSelection(table: any) {
    table.selected = !table.selected;
  }

  startDrag(event: MouseEvent, table: any) {
    this.draggingTable = table;
    this.offsetX = event.clientX - table.x;
    this.offsetY = event.clientY - table.y;

    window.addEventListener('mousemove', this.onDrag);
    window.addEventListener('mouseup', this.stopDrag);
  }

  onDrag = (event: MouseEvent) => {
    if (!this.draggingTable) return;

    this.draggingTable.x = event.clientX - this.offsetX;
    this.draggingTable.y = event.clientY - this.offsetY;
  };

  stopDrag = () => {
    this.draggingTable = null;
    window.removeEventListener('mousemove', this.onDrag);
    window.removeEventListener('mouseup', this.stopDrag);
  };
}
