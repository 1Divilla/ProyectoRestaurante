import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableMapComponent } from './table-map/table-map.component';
import { ReservationFormComponent } from './reservation-form/reservation-form.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: 'reserve', component: TableMapComponent }
];

@NgModule({
  declarations: [
    TableMapComponent,
    ReservationFormComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    TableMapComponent,
    ReservationFormComponent
  ]
})
export class ReserveModule {}
